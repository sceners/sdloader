package sdloader.util;

public class SystemPropertyUtil {

	public static String getLineSeparator() {
		return System.getProperty("line.separator");
	}
}
