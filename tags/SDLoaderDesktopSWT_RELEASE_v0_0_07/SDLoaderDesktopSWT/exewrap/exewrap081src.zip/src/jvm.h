
extern JNIEnv* CreateJavaVM(LPTSTR vm_args);
extern void    DestroyJavaVM();
extern JNIEnv* AttachJavaVM();
extern void    DetachJavaVM();
extern LPTSTR  GetProgramFiles();
extern LPTSTR  GetJavaVMPath();
extern LPTSTR  GetLibraryPath();
extern void    AddPath(const char* path);
extern LPTSTR  lstrrchr(LPTSTR source, TCHAR c);

extern JavaVM* jvm;
extern JNIEnv* env;

