#ifndef _DDE_CONNECT_H_
#define _DDE_CONNECT_H_

#define DDE_SERVER 0
#define DDE_CLIENT 1

#ifdef __cplusplus
extern "C" {
#endif

extern int dde_exec(void(*start_address)(void*), char* mutexName, int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif
